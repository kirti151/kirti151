public class PreDecrement {
    public static void main(String[] args) {
        int n=10;
        int preDec=--n;
        System.out.println("Pre decrement: "+preDec);
        
    }
}
