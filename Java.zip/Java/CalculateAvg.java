public class CalculateAvg {
    public static void main(String[] args) {
        int april=12;
        int may=14;
        int june=8;
        double avg=(april+may+june)/3.0;
        System.out.println("Synsets Entered for April: "+april);
        System.out.println("Synsets Entered for May: "+may);
        System.out.println("Synsets Entered for June: "+june);
        System.out.println("Synsets Entered for Average: "+avg);
    }
}
