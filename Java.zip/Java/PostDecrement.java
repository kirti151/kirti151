class PostDecrement{
    public static void main(String[] args) {
        int n=10;
        int postDec=n--;
        System.out.println("Post-Decrement: "+postDec);
        System.out.println("After post-decrement: "+n);
    }
}