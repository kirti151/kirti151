public class PrintValue {
    public static void main(String[] args) {
        int a_number=5;
        if(a_number==1)
          System.out.println("One");
        if(a_number==2)
          System.out.println("Two");
        if(a_number==3)
          System.out.println("Three");
        if(a_number==4)
          System.out.println("Four");
        if(a_number==5)
          System.out.println("Five");
    }
}
