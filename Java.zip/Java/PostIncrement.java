public class PostIncrement {
    public static void main(String[] args) {
        int n=10;
        int postIn=n++;
        System.out.println("Post-Increment: "+postIn);
        System.out.println("After postInc: "+n);
    }
}
