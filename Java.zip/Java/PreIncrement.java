public class PreIncrement {
    public static void main(String[] args) {
        int n=10;
        int preIn = ++n;
        System.out.print("Pre-Increment: "+preIn); 
    }
}
